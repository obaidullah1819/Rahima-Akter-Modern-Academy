# রাহিমা আক্তার মর্ডান একাডেমি — Firebase Ready

এই সংস্করণে Firebase Authentication, Firestore এবং Firebase Cloud Messaging (FCM)-এর dependency ও প্রাথমিক notification/repository code প্রস্তুত আছে।

## Firebase চালু করার জন্য যা লাগবে
1. Firebase Console-এ নতুন Android app/project তৈরি করুন।
2. Android package name দিন:
   `com.rahimaakter.modernacademy`
3. Firebase থেকে `google-services.json` ডাউনলোড করে `app/` ফোল্ডারে রাখুন।
4. Google Services plugin ইতিমধ্যে project-এ যোগ করা আছে।
5. Gradle Sync করুন।
6. Firebase Authentication-এ প্রয়োজনীয় sign-in method চালু করুন।
7. Firestore Database তৈরি করুন।
8. Cloud Messaging ব্যবহার করতে notification permission চালু রাখুন।

## এখন প্রস্তুত
- স্কুলের লোগো
- Login UI
- শিক্ষক/অভিভাবক/শিক্ষার্থী role
- আগামীকালের পড়া UI
- Firestore-এ পড়া publish করার repository
- FCM notification service
- Homework / Notice / Routine / Attendance / Result / Fee / News UI-এর ভিত্তি

## গুরুত্বপূর্ণ
`google-services.json` ছাড়া Firebase আপনার নির্দিষ্ট project-এর সাথে সংযুক্ত হবে না। এটি আপনার নিজের Firebase project থেকে নিতে হবে; কোনো ব্যক্তিগত password বা payment তথ্য এখানে পাঠানোর দরকার নেই।
