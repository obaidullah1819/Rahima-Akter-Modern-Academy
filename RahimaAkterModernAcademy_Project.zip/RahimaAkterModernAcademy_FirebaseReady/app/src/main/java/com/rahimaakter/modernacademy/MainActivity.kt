package com.rahimaakter.modernacademy

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.rahimaakter.modernacademy.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            val role = when (binding.roleGroup.checkedRadioButtonId) {
                R.id.rbTeacher -> "শিক্ষক"
                R.id.rbStudent -> "শিক্ষার্থী"
                else -> "অভিভাবক"
            }
            Toast.makeText(this, "$role লগইন — Prototype", Toast.LENGTH_SHORT).show()
        }

        binding.btnLessons.setOnClickListener {
            Toast.makeText(this, "আগামীকালের পড়া", Toast.LENGTH_SHORT).show()
        }
        binding.btnHomework.setOnClickListener {
            Toast.makeText(this, "হোমওয়ার্ক", Toast.LENGTH_SHORT).show()
        }
        binding.btnNotice.setOnClickListener {
            Toast.makeText(this, "নোটিশ", Toast.LENGTH_SHORT).show()
        }
        binding.btnRoutine.setOnClickListener {
            Toast.makeText(this, "রুটিন", Toast.LENGTH_SHORT).show()
        }
        binding.btnAttendance.setOnClickListener {
            Toast.makeText(this, "উপস্থিতি", Toast.LENGTH_SHORT).show()
        }
        binding.btnResult.setOnClickListener {
            Toast.makeText(this, "ফলাফল", Toast.LENGTH_SHORT).show()
        }
        binding.btnFee.setOnClickListener {
            Toast.makeText(this, "ফি / বেতন", Toast.LENGTH_SHORT).show()
        }
        binding.btnNews.setOnClickListener {
            Toast.makeText(this, "স্কুলের খবর", Toast.LENGTH_SHORT).show()
        }
    }
}
