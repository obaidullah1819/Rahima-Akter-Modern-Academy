package com.rahimaakter.modernacademy

import com.google.firebase.firestore.FirebaseFirestore

class AcademyRepository {
    private val db = FirebaseFirestore.getInstance()

    fun publishTomorrowLesson(
        className: String,
        subject: String,
        lesson: String,
        onDone: (Boolean) -> Unit
    ) {
        val data = hashMapOf(
            "className" to className,
            "subject" to subject,
            "lesson" to lesson,
            "createdAt" to System.currentTimeMillis()
        )
        db.collection("tomorrow_lessons")
            .add(data)
            .addOnSuccessListener { onDone(true) }
            .addOnFailureListener { onDone(false) }
    }
}
